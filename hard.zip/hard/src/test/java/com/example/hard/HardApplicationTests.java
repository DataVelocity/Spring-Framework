package com.example.hard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HardApplicationTests {

	@Test
	void contextLoads() {
	}

}
